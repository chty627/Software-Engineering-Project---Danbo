# Danbo Sprint1 小组提交报告

包含三个文件：

- Sprint1 测试文档 - Danbo 你说的都队(宁晨然组).pdf
  - 主要讲述后端测试的全过程
- Sprint1 阶段汇报 - Danbo 你说的都队(宁晨然组).pdf
  - 讲述Sprint1阶段内容，包括：
    - Sprint计划会议
    2. 每日Scrum站会
    3. Sprint评审会议
    4. Sprint回顾会议
    5. 需求和设计文档
    5. 前后端设计
- Sprint1 阶段汇报 - Danbo 你说的都队(宁晨然组).pptx
  - 现场展示PPT内容